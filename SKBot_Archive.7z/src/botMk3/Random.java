package botMk3;

public class Random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("RANDOM STUFF " + args[0]);
	}

}
