package botMk2;

import java.util.ArrayList;
import botMk2.Commands.*;

public class LoadCommands {


	public static ArrayList<Command> load()
	{
		ArrayList<Command> commands = new ArrayList<Command>();
		
		commands.add(new Random());
		
		return commands;
	}

}
