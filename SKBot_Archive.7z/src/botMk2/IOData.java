package botMk2;

public interface IOData{
	
	void sendData(String data);
	String getData();
}