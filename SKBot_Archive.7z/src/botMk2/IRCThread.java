package botMk2;

public class IRCThread extends Thread{
	
	public void poop()
	{
		System.out.println("IRCThread running");
	}
}
