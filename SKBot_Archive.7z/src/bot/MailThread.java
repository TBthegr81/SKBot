package bot;

public class MailThread extends Thread {
	MailThread()
	{
		System.out.println("New MailThread!");
	}
	
	public void run()
	{
		System.out.println("Stuff");
	}
}
